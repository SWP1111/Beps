// db.js

const { Pool } = require('pg');

const pool = new Pool({
  user: 'postgres',        // DB 사용자 이름
  host: 'localhost',        // DB 서버 주소
  database: 'beps', // 사용할 데이터베이스 이름
  password: 'postgres',// 비밀번호
  port: 5432,               // PostgreSQL 기본 포트
});

module.exports = pool;

